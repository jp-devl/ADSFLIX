import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Filme> filmes = new ArrayList<>();


        Filme f1 = new Filme();
        f1.nome = "O Poderoso Chefão";
        f1.anodelancamento = 1972;
        f1.avaliacao = 9.2;
        f1.genero = "Drama";
        f1.duracaoemmin = 175;

        Filme f2 = new Filme();
        f2.nome = "Vingadores: Ultimato";
        f2.anodelancamento = 2019;
        f2.avaliacao = 8.4;
        f2.genero = "Ação";
        f2.duracaoemmin = 181;

        Filme f3 = new Filme();
        f3.nome = "Interstellar";
        f3.anodelancamento = 2014;
        f3.avaliacao = 8.6;
        f3.genero = "Ficção Científica";
        f3.duracaoemmin = 169;

        Filme f4 = new Filme();
        f4.nome = "Forrest Gump - O Contador de Histórias";
        f4.anodelancamento = 1994;
        f4.avaliacao = 9.4;
        f4.genero = "Comédia";
        f4.duracaoemmin = 142;

        Filme f5 = new Filme();
        f5.nome = "Ilha do Medo";
        f5.anodelancamento = 2010;
        f5.avaliacao = 8.9;
        f5.genero = "Mistério";
        f5.duracaoemmin = 138;

        Filme f6 = new Filme();
        f6.nome = "Cidade de Deus";
        f6.anodelancamento = 2002;
        f6.avaliacao = 9.0;
        f6.genero = "Crime";
        f6.duracaoemmin = 130;

        Filme f7 = new Filme();
        f7.nome = "O Espanta Tubarões";
        f7.anodelancamento = 2004;
        f7.avaliacao = 6.9;
        f7.genero = "Infantil";
        f7.duracaoemmin = 90;

        filmes.add(f1);
        filmes.add(f2);
        filmes.add(f3);
        filmes.add(f4);
        filmes.add(f5);
        filmes.add(f6);
        filmes.add(f7);

        int opcao;

        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Ver todos os filmes");
            System.out.println("2. Filtrar por gênero");
            System.out.println("3. Filtrar por ano");
            System.out.println("4. Filtrar por avaliação mínima");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("\n--- Todos os Filmes ---");
                    for (Filme f : filmes) {
                        f.exibirDetalhes();
                    }
                    break;
                case 2:
                    System.out.print("Digite o gênero: ");
                    String genero = scanner.nextLine();
                    System.out.println("\n--- Filmes do gênero " + genero + " ---");
                    for (Filme f : filmes) {
                        if (f.genero.equalsIgnoreCase(genero)) {
                            f.exibirDetalhes();
                        }
                    }
                    break;
                case 3:
                    System.out.print("Digite o ano: ");
                    int ano = scanner.nextInt();
                    System.out.println("\n--- Filmes do ano " + ano + " ---");
                    for (Filme f : filmes) {
                        if (f.anodelancamento == ano) {
                            f.exibirDetalhes();
                        }
                    }
                    break;
                case 4:
                    System.out.print("Digite a avaliação mínima: ");
                    double nota = scanner.nextDouble();
                    System.out.println("\n--- Filmes com avaliação acima de " + nota + " ---");
                    for (Filme f : filmes) {
                        if (f.avaliacao >= nota) {
                            f.exibirDetalhes();
                        }
                    }
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        scanner.close();
    }
}
