public class Filme {
    public String nome;
    public int ano;
    public String genero;
    public double nota;

    public Filme(String nome, int ano, String genero, double nota) {
        this.nome = nome;
        this.ano = ano;
        this.genero = genero;
        this.nota = nota;
    }

    public String toJson() {
        return String.format("{\"nome\":\"%s\", \"ano\":%d, \"genero\":\"%s\", \"nota\":%.1f}", nome, ano, genero, nota);
    }
}
