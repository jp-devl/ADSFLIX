const moviesContainer = document.getElementById('moviesContainer');
const myListContainer = document.getElementById('myListContainer');
const emptyListMessage = document.getElementById('emptyListMessage');
const trailerModal = document.getElementById('trailerModal');
const trailerVideo = document.getElementById('trailerVideo');

let listaFavoritos = JSON.parse(localStorage.getItem('favoritos')) || [];

const apiKey = '5a1308a9401953c30d77a345755d3a64'; // <-- Coloque sua API KEY do TMDB aqui

function buscarFilmes() {
    fetch(`https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}&language=pt-BR&page=1`)
        .then(res => res.json())
        .then(data => {
            const filmes = data.results;
            moviesContainer.innerHTML = '';

            filmes.forEach(filme => {
                const isFavorito = listaFavoritos.includes(filme.id.toString());

                const card = document.createElement('div');
                card.className = 'movie-card';

                card.innerHTML = `
                    <img src="https://image.tmdb.org/t/p/w300${filme.poster_path}" alt="${filme.title}" />
                    <button class="favorite-btn ${isFavorito ? 'active' : ''}" data-id="${filme.id}">❤️</button>
                    <div class="movie-info">
                        <h3>${filme.title}</h3>
                        <div class="movie-meta">
                            <span>${filme.release_date.split('-')[0]}</span>
                            <span class="rating">⭐ ${filme.vote_average}</span>
                        </div>
                    </div>
                    <button class="play-btn" data-id="${filme.id}"><i class="fas fa-play"></i></button>
                `;

                moviesContainer.appendChild(card);
            });

            ativarEventos();
            carregarMinhaLista();
        })
        .catch(err => {
            moviesContainer.innerHTML = '<p>Erro ao carregar filmes.</p>';
            console.error(err);
        });
}

function ativarEventos() {
    document.querySelectorAll('.favorite-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const filmeId = btn.getAttribute('data-id');
            toggleFavorito(filmeId, btn);
        });
    });

    document.querySelectorAll('.play-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const filmeId = btn.getAttribute('data-id');
            buscarTrailer(filmeId);
        });
    });
}

function toggleFavorito(id, btn) {
    const index = listaFavoritos.indexOf(id);
    if (index > -1) {
        listaFavoritos.splice(index, 1);
        btn.classList.remove('active');
    } else {
        listaFavoritos.push(id);
        btn.classList.add('active');
    }
    localStorage.setItem('favoritos', JSON.stringify(listaFavoritos));
    carregarMinhaLista();
}

function carregarMinhaLista() {
    if (listaFavoritos.length === 0) {
        myListContainer.innerHTML = '';
        emptyListMessage.style.display = 'block';
        return;
    }

    emptyListMessage.style.display = 'none';
    myListContainer.innerHTML = '';

    listaFavoritos.forEach(id => {
        fetch(`https://api.themoviedb.org/3/movie/${id}?api_key=${apiKey}&language=pt-BR`)
            .then(res => res.json())
            .then(filme => {
                const card = document.createElement('div');
                card.className = 'movie-card';

                card.innerHTML = `
                    <img src="https://image.tmdb.org/t/p/w300${filme.poster_path}" alt="${filme.title}" />
                    <button class="favorite-btn active" data-id="${filme.id}">❤️</button>
                    <div class="movie-info">
                        <h3>${filme.title}</h3>
                        <div class="movie-meta">
                            <span>${filme.release_date.split('-')[0]}</span>
                            <span class="rating">⭐ ${filme.vote_average}</span>
                        </div>
                    </div>
                    <button class="play-btn" data-id="${filme.id}"><i class="fas fa-play"></i></button>
                `;

                myListContainer.appendChild(card);
                ativarEventos();
            });
    });
}

function buscarTrailer(filmeId) {
    fetch(`https://api.themoviedb.org/3/movie/${filmeId}/videos?api_key=${apiKey}&language=pt-BR`)
        .then(res => res.json())
        .then(data => {
            const trailer = data.results.find(video => video.type === 'Trailer' && video.site === 'YouTube');
            if (trailer) {
                const trailerUrl = `https://www.youtube.com/embed/${trailer.key}`;
                abrirModal(trailerUrl);
            } else {
                alert('Trailer não disponível.');
            }
        });
}

function abrirModal(url) {
    trailerVideo.src = url;
    trailerModal.style.display = 'flex';
}

function closeModal() {
    trailerVideo.src = '';
    trailerModal.style.display = 'none';
}

window.closeModal = closeModal;
window.onload = buscarFilmes;
